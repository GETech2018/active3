try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 466,
                            h: 466,
                            src: '2.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 22,
                            hour_startY: 159,
                            hour_array: [
                                '3.png',
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png'
                            ],
                            hour_space: -16,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 227,
                            minute_startY: 155,
                            minute_array: [
                                '13.png',
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png'
                            ],
                            minute_space: -16,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            second_zero: 1,
                            second_startX: 324,
                            second_startY: 314,
                            second_array: [
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png',
                                '27.png',
                                '28.png',
                                '29.png',
                                '30.png',
                                '31.png',
                                '32.png'
                            ],
                            second_space: -6,
                            second_align: hmUI__default.default.align.LEFT,
                            second_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 466,
                            h: 466,
                            src: '33.png',
                            show_level: hmUI__default.default.show_level.ONLY_AOD
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 22,
                            hour_startY: 159,
                            hour_array: [
                                '3.png',
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png'
                            ],
                            hour_space: -16,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 227,
                            minute_startY: 155,
                            minute_array: [
                                '13.png',
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png'
                            ],
                            minute_space: -16,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_AOD
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}